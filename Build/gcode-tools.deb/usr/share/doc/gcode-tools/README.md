# gcode-tools

DEBIAN 8 installation: 

wget https://github.com/VESSEA/gcode-tools/raw/master/gcode-tools.deb

dpkg -i gcode-tools.deb

https://github.com/VESSEA/gcode-tools

